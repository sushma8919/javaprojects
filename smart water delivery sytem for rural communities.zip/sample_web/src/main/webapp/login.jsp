<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Smart Water Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="./CSS/login.css"/>
<body>
<body>

<div class="login-card">

<h3 class="login-title">💧 Smart Water Login</h3>

<!-- USER LOGIN -->
<form action="UserLoginServlet" method="post">

<div class="mb-3">
<label>Email</label>
<input type="email" name="email" class="form-control" required>
</div>

<div class="mb-3">
<label>Password</label>
<input type="password" name="password" class="form-control" required>
</div>

<div class="d-grid">
<button type="submit" class="btn btn-primary">User Login</button>
</div>

</form>

<!-- LINKS -->
<div class="footer-links">

  <a href="register.jsp">Register as User</a> 
  
  <a href="admin_login.jsp">Admin Login</a> 
  
  <a href="vendor_login.jsp">Vendor Login</a>

</div>

</div>

</body>
</html>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>home | sample_web</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="./CSS/home.css"/>

</head>
<body>
<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
<div class="container">
  <a class="navbar-brand fw-bold" href="#">💧 Smart Water</a>
  <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#menu">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="menu">
    <ul class="navbar-nav ms-auto">
      <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
      <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
      <li class="nav-item"><a class="nav-link" href="#">Help</a></li>
      <li class="nav-item"><a class="nav-link" href="admin/userlogin.jsp">Login</a></li>

</a></li>
    </
  </div>
</div>
</nav>

<!-- HERO SECTION -->
<section class="hero">
<div class="container">
  <div class="row align-items-center">

    <!-- LEFT CONTENT -->
    <div class="col-lg-6 mb-4">
      <h1>Smart Water Delivery System for Rural Communities</h1>
      <p class="mt-3">
        Easy, reliable and digital water delivery connecting rural users
        with trusted local vendors.
      </p>
      <!-- <a href="#" class="btn btn-primary btn-lg mt-3">Get Started</a> -->
    </div>

    

  </div>
</div>
</section>

<!-- FEATURES -->
<section class="py-5">
<div class="container text-center">
  <h2 class="section-title mb-4">Why Choose Smart Water?</h2>

  <div class="row">
    <div class="col-md-4 mb-4">
      <div class="card h-100 shadow-sm">
        <div class="card-body">
          <h5>🚚 Easy Ordering</h5>
          <p>Order water cans online without physical effort.</p>
        </div>
      </div>
    </div>

    <div class="col-md-4 mb-4">
      <div class="card h-100 shadow-sm">
        <div class="card-body">
          <h5>💳 Digital Payments</h5>
          <p>Safe and secure digital payment options.</p>
        </div>
      </div>
    </div>

    <div class="col-md-4 mb-4">
      <div class="card h-100 shadow-sm">
        <div class="card-body">
          <h5>📍 Live Tracking</h5>
          <p>Track your water delivery in real-time.</p>
        </div>
      </div>
    </div>
  </div>
</div>
</section>

<!-- FOOTER -->
<footer class="pt-4 pb-3">
<div class="container">
  <div class="row">

    <div class="col-md-4 mb-3">
      <h5 class="text-white">Smart Water</h5>
      <p>Providing clean water access to rural communities using digital solutions.</p>
    </div>

    <div class="col-md-4 mb-3">
      <h5 class="text-white">Quick Links</h5>
      <ul class="list-unstyled">
        <li><a href="#">Home</a></li>
        <li><a href="#">Contact</a></li>
        <li><a href="#">Help</a></li>
        <li><a href="admin/userlogin.jsp">Login</a></li>


      </ul>
    </div>

    <div class="col-md-4 mb-3">
      <h5 class="text-white">Contact</h5>
      <p>Email: sushma@smartwater.com</p>
      <p>Phone: +91 9059193950</p>
    </div>

  </div>

  <hr class="border-secondary">
  <p class="text-center mb-0">
    © 2026 Smart Water Delivery System. All rights reserved.
  </p>
</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>


<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>



<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>delete | sample_web</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../CSS/delete.css"/>
</head>
<body>

<%
String GET_USER_BY_ID = "select * from users1 where user_id = ?";
String user_id = request.getParameter("user_id");

System.out.println(user_id);
int  userid=0;
String user_name="";
String email="";
String password="";
String gender="";
long  phone_number=0;
String address="";
String city="";
int pincode=0;


try{
	Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8");
    PreparedStatement ps = con.prepareStatement(GET_USER_BY_ID);
    ps.setString(1,user_id);
    
    
    ResultSet rs = ps.executeQuery();
    
    if(rs.next()) {
    	userid=rs.getInt(1);
    	user_name=rs.getString(2);
    	email=rs.getString(3);
		password=rs.getString(4);
		gender=rs.getString(5);
		phone_number=rs.getLong(6);
		address=rs.getString(7);
		city=rs.getString(8);
		pincode=rs.getInt(9);
		System.out.println( user_name + email + password + gender + phone_number + address + city + pincode);
    }
}catch(Exception e){
    e.printStackTrace();
}

%>

		
<!-- TITLE BAR -->
<div class="title-bar">
  💧 Smart Water Delivery
</div>

<!-- NAVBAR BELOW TITLE -->
<nav class="navbar navbar-expand-lg navbar-custom shadow-sm">
  <div class="container d-flex justify-content-between align-items-center">
    
    <!-- Left menu: Home + Users dropdown -->
    <ul class="navbar-nav flex-row">
      <li class="nav-item me-3"><a class="nav-link active" href="#">Home</a></li>

      <!-- Users Dropdown -->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="usersDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Users
        </a>
        <ul class="dropdown-menu" aria-labelledby="usersDropdown">
          
          <li><a class="dropdown-item" href="#">Delete User</a></li>
          
         </ul>
      </li>
    </ul>

    <!-- Right menu: Logout button -->
    <a href="login.html" class="btn btn-logout">Logout</a>

    <!-- Toggle button for mobile -->
    <button class="navbar-toggler ms-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

  </div>
</nav>

<!-- ADD USER FORM CARD -->
<div class="admin-card">
  <h3>Delete User</h3>
  <form action="./delete_user_controller.jsp" method="post">

<input type="hidden" name="user_id" value="<%=user_id%>">

<div class="mb-3">
      <label class="form-label"> user_id</label>
      <input type="text" class="form-control" name="user_id"  disabled="disabled" value ="<%=user_id%>" placeholder=" name" required>
    </div>
   <!-- FIRST NAME -->
    <div class="mb-3">
      <label class="form-label"> Name</label>
      <input type="text" class="form-control" name="user_name" disabled="disabled"  value ="<%=user_name%>" placeholder=" name" required>
    </div>

 
    <!-- EMAIL -->
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" class="form-control" name="email" disabled="disabled" value ="<%=email%>" placeholder="email" required>
    </div>
    <!-- PASSWORD -->
    <div class="mb-3">
      <label class="form-label">Password</label>
      <input type="text" class="form-control" name="password" disabled="disabled" value ="<%=password%>" placeholder="Password" required>
    </div>

    <!-- GENDER -->
    <div class="mb-3">
      <label class="form-label">Gender</label>
      <input type="text" class="form-control" name="gender" disabled="disabled" value ="<%=gender%>" placeholder="gender" required>
     <%--  <select class="form-control" name="gender" value ="<%=gender%>" placeholder="gender"required>
        <option value=""disabled selected>Select gender</option>
        <option name="gender" value ="male">Male</option>
        <option name="gender"value ="female">Female</option>
        <optionname="gender" value="other">Other</option>
      </select>
    --%>
</div>
<!-- PHONE NUMBER -->
<div class="mb-3">
  <label class="form-label">Phone Number</label>
  <input type="text" class="form-control" name="phoneNumber"
        disabled="disabled"  value="<%=phone_number%>"
         placeholder="Enter phone number" required>
</div>
     <!-- ADDRESS -->
    <div class="mb-3">
      <label class="form-label">Address</label>
      <input class="form-control" name="address" disabled="disabled" value ="<%=city%>" placeholder="Enter address" required>
    </div>
<!-- CITY -->
<div class="mb-3">
  <label class="form-label">City</label>
  <input type="text" name="city" class="form-control" disabled="disabled" value ="<%=city%>"placeholder="Enter city" required>
</div>

<!-- PINCODE -->
<div class="mb-3">
  <label class="form-label">Pincode</label>
  <input type="text" name="pincode" class="form-control" disabled="disabled" value ="<%=pincode%>"placeholder="Enter pincode" required>
</div>
     <!-- DELETE& BACK BUTTONS CENTERED -->
    <div class="d-flex justify-content-center gap-3 mt-3">
      <button type="submit" class="btn btn-primary">Delete</button>
      <button type="reset" class="btn btn-secondary">back</button>
    </div>
  </form>
</div></div>
  </form>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
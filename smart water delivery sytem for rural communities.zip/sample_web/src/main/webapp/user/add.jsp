<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Add user | sample_web</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../CSS/adduser.css"/>

</head>
<body>
<!-- TITLE BAR -->
<div class="title-bar">
  💧 Smart Water Delivery
</div>

<!-- NAVBAR BELOW TITLE -->
<nav class="navbar navbar-expand-lg navbar-custom shadow-sm">
  <div class="container d-flex justify-content-between align-items-center">
    
    <!-- Left menu: Home + Users dropdown -->
    <ul class="navbar-nav flex-row">
      <li class="nav-item me-3"><a class="nav-link active" href="#">Home</a></li>

      <!-- Users Dropdown -->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="usersDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Users
        </a>
        <ul class="dropdown-menu" aria-labelledby="usersDropdown">
          <li><a class="dropdown-item" href="#">Add User</a></li>
          
         </ul>
      </li>
    </ul>

    <!-- Right menu: Logout button -->
    <a href="login.html" class="btn btn-logout">Logout</a>

    <!-- Toggle button for mobile -->
    <button class="navbar-toggler ms-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

  </div>
</nav>

<!-- ADD USER FORM CARD -->
<div class="admin-card">
  <h3>➕ Add User</h3>
<form action="add_controller.jsp" method="post">

  
    <!-- FIRST NAME -->
    <div class="mb-3">
      <label class="form-label"> Name</label>
      <input type="text" class="form-control" name="user_name" placeholder="name" required>
    </div>

    
    <!-- EMAIL -->
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" class="form-control" name="email" placeholder="Enter email" required>
    </div>
<!-- PASSWORD -->
    <div class="mb-3">
      <label class="form-label">Password</label>
      <input type="text" class="form-control" name="password" placeholder="Password" required>
    </div>
    <!-- GENDER -->
    <div class="mb-3">
      <label class="form-label">Gender</label>
      <select class="form-control" name="gender" required>
        <option value="" disabled selected>Select gender</option>
        <option name="gender" value="male">Male</option>
        <option name="gender" value="female">Female</option>
        <option name="gender" value="other">Other</option>
      </select>
    </div>

    
    <!-- PHONE NUMBER -->
<div class="mb-3">
  <label class="form-label">Phone Number</label>
  <input type="text"  class="form-control" name="phone_number" placeholder="Enter phone number" required>
</div>
    <!-- ADDRESS -->
    <div class="mb-3">
      <label class="form-label">Address</label>
      <textarea class="form-control" rows="3" name="address" placeholder="Enter address" required></textarea>
    </div>
<!-- CITY -->
<div class="mb-3">
  <label class="form-label">City</label>
  <input type="text" name="city" class="form-control" name="city" placeholder="Enter city" required>
</div>

<!-- PINCODE -->
<div class="mb-3">
  <label class="form-label">Pincode</label>
  <input type="text" name="pincode" class="form-control"name="pincode" placeholder="Enter pincode" required>
</div>
    

     <!-- ADD & CLEAR BUTTONS CENTERED -->
    <div class="d-flex justify-content-center gap-3 mt-3">
      <button type="submit" class="btn btn-primary">Add</button>
      <button type="reset" class="btn btn-secondary">Clear</button>
    </div>
  
</div>
</div>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
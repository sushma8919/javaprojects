
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>


<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>add user controller </title>
</head>
<body>
<%
String name = request.getParameter("user_name");
String email = request.getParameter("email");
String password = request.getParameter("password");


String phonenumber = request.getParameter("phone_number");

String gender = request.getParameter("gender");

String address = request.getParameter("address");
String city= request.getParameter("city");
String pincode = request.getParameter("pincode");
System.out.println("name:   "  + name);
System.out.println("Phone: " + phonenumber );


try{
    Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con = DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8");

    String sql = "INSERT INTO users1 ( user_id,user_name, email, password,gender,phone_number,address,city,pincode,created_at) VALUES (user_seq.nextval, ?, ?, ?, ?, ?,?,?,?,SYSDATE )";

    PreparedStatement pst = con.prepareStatement(sql);

    pst.setString(1, name);
    pst.setString(2, email);
    pst.setString(3, password);
    pst.setString(4, gender);
    pst.setString(5,phonenumber);
    pst.setString(6,address);
    pst.setString(7,city);
    pst.setString(8,pincode);
    
    

    int i = pst.executeUpdate();

    if(i > 0){
        out.println("add Successful");
    } else {
        out.println(" Failed");
    }

    con.commit();

} catch(Exception e){
    out.println(e);
}
%>

</body>
</html>

<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>view | sample_web</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="../CSS/view.css"/>
</head>
<body>

<%

String GET_ALL_USERS = "select * from users1" ;

try {
	Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8");
    PreparedStatement ps = con.prepareStatement(GET_ALL_USERS);
    ResultSet rs = ps.executeQuery();%>
    
    
    

<!-- TITLE BAR -->
<div class="title-bar">
  💧 Smart Water Delivery
</div>

<!-- NAVBAR BELOW TITLE -->
<nav class="navbar navbar-expand-lg navbar-custom shadow-sm">
  <div class="container d-flex justify-content-between align-items-center">
    
    <!-- Left menu -->
    <ul class="navbar-nav flex-row">
      <li class="nav-item me-3">
        <a class="nav-link active" href="#">Home</a>
      </li>

      <!-- Users Dropdown -->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="usersDropdown" role="button" data-bs-toggle="dropdown">
          Users
        </a>

        <ul class="dropdown-menu">
          
          <li><a class="dropdown-item" href="#">View All Users</a></li>
        </ul>
      </li>
    </ul>

    <!-- Logout -->
    <a href="login.html" class="btn btn-logout">Logout</a>

  </div>
</nav>

<!-- VIEW ALL USERS TABLE -->
<div class="admin-card">
  <h3>👥 View All Users</h3>
<table class="table-custom">
 <!--    <thead> -->
      <tr>
      <th>user_id</th>
        <th> name</th>
        <th>Email</th>
        <th>password</th>
        <th>Gender</th>
        <th>phone_number</th>
        <th>Address</th>
        <th>city</th>
        <th>pincode</th>
        <th>created_at</th>
        
      </tr>
<!--     </thead> -->
    
   <%  while(rs.next()) { %>
   
   <tr>
   <td><%=rs.getInt(1) %></td>
   <td><%=rs.getString(2) %></td>
   <td><%=rs.getString(3) %></td>
   <td><%=rs.getString(4) %></td>
   <td><%=rs.getString(5) %></td>
   <td><%=rs.getLong(6) %></td>
   <td><%=rs.getString(7) %></td>
   <td><%=rs.getString(8) %></td>
      <td><%=rs.getInt(9) %></td>
         <td><%=rs.getString(10) %></td>
   </tr>
   
   
   
   <%}%> 
   </table>
    	
<% }catch(Exception e){
    e.printStackTrace();
} %>
 
</body>
</html>
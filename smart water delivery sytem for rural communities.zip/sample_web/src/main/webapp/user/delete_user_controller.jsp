<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>

<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>delete user </title>
</head>
<body>

<%

String DELETE_USER = "delete from users1 where user_id =?";
String u_id=request.getParameter("user_id");
int user_id=Integer.parseInt(u_id);

try{
	Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8");
    PreparedStatement ps = con.prepareStatement( DELETE_USER);
    ps.setInt(1,user_id);

	int i = ps.executeUpdate();

	if (i > 0) {
		out.println("delete Successfully");
	} else {
		out.println("delete Failed");
	} 

} catch (Exception e) {
	e.printStackTrace(); 
}   
%>

</body>
</html>
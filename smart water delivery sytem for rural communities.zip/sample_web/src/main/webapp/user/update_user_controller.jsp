<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>

<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>update user controller</title>
</head>
<body>
<%
String u_id=request.getParameter("user_id");
int user_id=Integer.parseInt(u_id);
String user_name = request.getParameter("user_name");
String email = request.getParameter("email");
String password = request.getParameter("password");


String phonenumber = request.getParameter("phone_number");


String gender = request.getParameter("gender");

String address = request.getParameter("address");
String city= request.getParameter("city");
String pcode = request.getParameter("pincode");
int pincode =Integer.parseInt(pcode);

System.out.println(user_id);
System.out.println(user_name);
System.out.println(email);
System.out.println(password);
System.out.println(phonenumber);
System.out.println(gender);

System.out.println(address);
System.out.println(city);
System.out.println(pincode);
String UPDATE_USER = "update users1 set user_name=?, email=?, password=?,phone_number=?,gender=?,address=?,city=?,pincode=? where user_id=?";

try {

	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "batch8", "batch8");
	PreparedStatement ps = con.prepareStatement(UPDATE_USER);
	
	ps.setString(1, user_name);
	ps.setString(2, email);
	ps.setString(3, password);
	ps.setString(4, phonenumber);
	ps.setString(5, gender);
	ps.setString(6, address);
	ps.setString(7, city);
	ps.setInt(8, pincode);
	ps.setInt(9, user_id);

	int i = ps.executeUpdate();

	if (i > 0) {
		out.println("updated Successfully");

	} else {
		out.println("updated Failed");
	}

} catch (Exception e) {
	e.printStackTrace();
}
%>
</body>
</html>
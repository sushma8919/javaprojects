<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>registration | sample_web</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="./CSS/register.css"/>
</head>
<body>
<div class="register-card">

<h3 class="title">💧 new user</h3>

<form action="RegisterServlet" method="post">

<div class="mb-3">
<label>Name</label>
<input type="text" name="name" class="form-control" required>
</div>

<div class="mb-3">
<label>Email</label>
<input type="email" name="email" class="form-control" required>
</div>
<!-- 👇 IKADA PASSWORD SECTION PETTALI -->
<div class="mb-3">
<label>Create Password</label>
<input type="password" id="password" name="password" 
class="form-control" required>
</div>

<div class="mb-3">
<label>Address</label>
<textarea name="address" class="form-control" placeholder="Enter Address" rows="3" required></textarea>
</div>

<div class="mb-3">
<label>Gender</label><br>

<input type="radio" name="gender" value="Male" required> Male
<input type="radio" name="gender" value="Female"> Female
<input type="radio" name="gender" value="Other"> Other

</div>
<div class="d-grid">
<button type="submit" class="btn btn-primary">Register</button>
</div>
</form>

<div class="text-center mt-3">
<a href="login.html"> Login</a>
</div>

</div>


</body>
</html>
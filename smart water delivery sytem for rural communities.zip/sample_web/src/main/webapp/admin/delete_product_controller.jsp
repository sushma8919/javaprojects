<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>

<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Delete Product Controller</title>
</head>
<body>

<%
/* 🔒 Session Check */
if(session.getAttribute("vendor_id") == null){
    response.sendRedirect("login.html");
    return;
}

/* 📥 Get session vendor */
int vendor_id = (Integer)session.getAttribute("vendor_id");

/* 📥 Get product id */
String p_id = request.getParameter("product_id");
int product_id = Integer.parseInt(p_id);

/* 🔥 Secure Delete Query */
String DELETE_PRODUCT = "DELETE FROM products WHERE product_id=? AND vendor_id=?";

try {
    Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con = DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8");

    PreparedStatement ps = con.prepareStatement(DELETE_PRODUCT);

    ps.setInt(1, product_id);
    ps.setInt(2, vendor_id); // 🔥 security

    int i = ps.executeUpdate();

    if (i > 0) {
%>
        <h3 style="color:green;text-align:center;">Product Deleted Successfully</h3>
<%
    } else {
%>
        <h3 style="color:red;text-align:center;">Delete Failed or Unauthorized</h3>
<%
    }

} catch (Exception e) {
    out.println(e);
}
%>

</body>
</html>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>

<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Delete Vendor | Smart Water Delivery</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Add Vendor CSS for consistency -->
<link rel="stylesheet" href="../CSS/deleteven.css"/>

<style>
.btn-delete {
    background-color: #dc3545;
    color: white;
}
.btn-delete:hover {
    background-color: #a71d2a;
}
.btn-back {
    background-color: #6c757d;
    color: white;
}
.btn-back:hover {
    background-color: #5a6268;
}
</style>

</head>
<body>

<%
String GET_VENDOR_BY_ID = "select * from vendor where vendor_id = ?";
String vendor_id = request.getParameter("vendor_id");

int vendorid=0;
String name="";
String email="";
String password="";
String phonenumber="";
String shop_name="";
String rating="";
String shop_address="";
String location="";
String pincode="";

try{
	Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con = DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8");
    PreparedStatement ps = con.prepareStatement(GET_VENDOR_BY_ID);
    ps.setString(1,vendor_id);
    
    ResultSet rs = ps.executeQuery();
    if(rs.next()) {
		vendorid = rs.getInt("vendor_id");
		name = rs.getString("vendor_name");
		email = rs.getString("vendor_email");
		password = rs.getString("password");
		phonenumber = rs.getString("phone_number");
		shop_name = rs.getString("shop_name");
		rating = rs.getString("rating");
		shop_address = rs.getString("shop_address");
		location = rs.getString("location");
		pincode = rs.getString("pincode");
    }
}catch(Exception e){
    e.printStackTrace();
}
%>

<div class="title-bar">
💧 Smart Water Delivery System for Rural Communities
</div>

<nav class="navbar navbar-expand-lg navbar-custom">
  <div class="container d-flex justify-content-between">
    <ul class="navbar-nav flex-row">
      <li class="nav-item me-3"><a class="nav-link" href="#">Home</a></li>
      <li class="nav-item"><a class="nav-link active" href="#">Vendors</a></li>
    </ul>
    <a href="login.html" class="btn btn-logout">Logout</a>
  </div>
</nav>

<div class="admin-card">
<h3>🗑 Delete Vendor</h3>

<form action="delete_vendor_controller.jsp" method="post">
  <!-- Vendor ID -->
  <div class="mb-3">
    <label class="form-label">Vendor ID</label>
    <input type="text" name="vendor_id" class="form-control" 
           value="<%=vendorid%>" readonly>
  </div>
  
  <!-- Vendor Name -->
  <div class="mb-3">
    <label class="form-label">Vendor Name</label>
    <input type="text" class="form-control" value="<%=name%>" readonly>
  </div>

  <!-- Email -->
  <div class="mb-3">
    <label class="form-label">Email</label>
    <input type="email" class="form-control" value="<%=email%>" readonly>
  </div>

  <!-- Phone Number -->
  <div class="mb-3">
    <label class="form-label">Phone Number</label>
    <input type="text" class="form-control" value="<%=phonenumber%>" readonly>
  </div>

  <!-- Shop Name -->
  <div class="mb-3">
    <label class="form-label">Shop Name</label>
    <input type="text" class="form-control" value="<%=shop_name%>" readonly>
  </div>

  <!-- Rating -->
  <div class="mb-3">
    <label class="form-label">Rating</label>
    <input type="number" class="form-control" value="<%=rating%>" readonly>
  </div>

  <!-- Shop Address -->
  <div class="mb-3">
    <label class="form-label">Shop Address</label>
    <textarea class="form-control" rows="3" readonly><%=shop_address%></textarea>
  </div>

  <!-- Location -->
  <div class="mb-3">
    <label class="form-label">Location</label>
    <input type="text" class="form-control" value="<%=location%>" readonly>
  </div>

  <!-- Pincode -->
  <div class="mb-3">
    <label class="form-label">Pincode</label>
    <input type="text" class="form-control" value="<%=pincode%>" readonly>
  </div>

  <!-- DELETE & BACK BUTTONS -->
  <div class="d-flex justify-content-center gap-3 mt-4">
    <button type="submit" class="btn btn-delete"
            onclick="return confirm('Are you sure you want to delete this vendor?');">
      Delete Vendor
    </button>
    <button type="button" class="btn btn-back" onclick="history.back()">Back</button>
  </div>

</form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
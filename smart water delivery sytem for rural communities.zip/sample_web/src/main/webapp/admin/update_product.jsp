<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>


<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>update Product | Smart Water Delivery</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

/* Blue Background */
body {
    background: linear-gradient(135deg, #0d6efd, #0a58ca);
    min-height: 100vh;
    font-family: Arial, sans-serif;
}

/* Title Bar */
.title-bar {
    background-color: #0a58ca;
    color: white;
    padding: 15px;
    font-size: 22px;
    font-weight: bold;
    text-align: center;
}

/* Navbar */
.navbar-custom {
    background-color: #084298;
}

.navbar-custom .nav-link {
    color: white;
    font-weight: 500;
}

.navbar-custom .nav-link:hover {
    color: #cfe2ff;
}

.navbar-custom .nav-link.active {
    text-decoration: underline;
}

/* Card */
.admin-card {
    background: white;
    max-width: 650px;
    margin: 40px auto;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.25);
}

/* Heading */
.admin-card h3 {
    text-align: center;
    color: #0d6efd;
    margin-bottom: 20px;
}

/* Inputs */
.form-control {
    border-radius: 8px;
}

/* Buttons */
.btn-submit {
    background-color: #0d6efd;
    color: white;
    padding: 8px 20px;
    border: none;
}

.btn-submit:hover {
    background-color: #084298;
}

.btn-back {
    background-color: #6c757d;
    color: white;
    padding: 8px 20px;
    border: none;
}

.btn-logout {
    background-color: #dc3545;
    color: white;
}

.mb-3 label {
    font-weight: 500;
}

</style>

</head>
<body>


<%
String GET_PRODUCT_BY_ID = "SELECT * FROM PRODUCTS WHERE PRODUCT_ID = ?";
String product_id = request.getParameter("product_id");
int productid=0;
int vendorid = (Integer)session.getAttribute("vendor_id");
String vendor_name = (String)session.getAttribute("vendor_name");
String product_name="";
String description="";
Double price = 0.0;
int quantity=0;

try{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con = DriverManager.getConnection(
	"jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8");

	PreparedStatement ps = con.prepareStatement(GET_PRODUCT_BY_ID);
	ps.setString(1,product_id);

	ResultSet rs = ps.executeQuery();
	
	if(rs.next()) {
		
		productid=rs.getInt("product_id");
		vendorid=rs.getInt("vendor_id");
		vendor_name=rs.getString("vendor_name");
		product_name=rs.getString("product_name");
		description=rs.getString("description");
		price=rs.getDouble("price");
		quantity = rs.getInt("quantity");
	}

	}catch(Exception e){
		out.println(e);
	}
	%>
				
	}
<!-- Title -->
<div class="title-bar">
💧 Smart Water Delivery System for Rural Communities
</div>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-custom">
  <div class="container d-flex justify-content-between">
    <ul class="navbar-nav flex-row">
      <li class="nav-item me-3"><a class="nav-link" href="#">Home</a></li>
      <li class="nav-item"><a class="nav-link active" href="#">Products</a></li>
    </ul>
    <a href="login.html" class="btn btn-logout">Logout</a>
  </div>
</nav>

<!-- Form Card -->
<div class="admin-card">
<h3>update Product</h3>

<form action="update_product_controller.jsp" method="post">
    <input type="hidden" name="product_id" value="<%= product_id %>">

<!-- Vendor ID -->
<div class="mb-3">
<label class="form-label">Vendor ID</label>
<input type="number" name="vendor_id" value="<%=vendorid%>" class="form-control" readonly>

</div>

<!-- Vendor Name -->
<div class="mb-3">
<label class="form-label">Vendor Name</label>

<input type="text" name="vendor_name" value="<%=vendor_name%>" class="form-control" readonly>
</div>

<!-- Product Name -->
<div class="mb-3">
<label class="form-label">Product Name</label>
<input type="text" name="product_name" value="<%=product_name%>" class="form-control" required>
</div>


<!-- Product Image -->
<div class="mb-3">
<label class="form-label">Product Image</label>
<input type="file" name="product_image" class="form-control">
</div>

<!-- Description -->
<div class="mb-3">
<label class="form-label">Description</label>
<textarea name="description" class="form-control" rows="3"><%= description %></textarea>
</div>

<!-- Price -->
<div class="mb-3">
<label class="form-label">Price (₹)</label>
<input type="number" step="0.01" name="price" value="<%=price%>" class="form-control" required>
</div>

<!-- Quantity -->
<div class="mb-3">
<label class="form-label">Quantity</label>
<input type="number" name="quantity" value="<%=quantity%>" class="form-control" required min="0">
</div>

<!-- Buttons -->
<div class="text-center mt-4">
<button type="button" onclick="history.back()" class="btn btn-back">⬅ Back</button>
<button type="submit" class="btn btn-submit">update Product</button>
</div>

</form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
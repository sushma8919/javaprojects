<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>

<%
int user_id = Integer.parseInt(request.getParameter("user_id"));
String user_name = request.getParameter("user_name");
String email = request.getParameter("email");
String password = request.getParameter("password");
String gender = request.getParameter("gender");
String phone_number = request.getParameter("phone_number");
String address = request.getParameter("address");
String city = request.getParameter("city");
int pincode = Integer.parseInt(request.getParameter("pincode"));

Connection con = null;
PreparedStatement ps = null;

try {
    Class.forName("oracle.jdbc.driver.OracleDriver");
    con = DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8");

    String UPDATE_QUERY = "UPDATE users1 SET user_name=?, email=?, password=?, gender=?, phone_number=?, address=?, city=?, pincode=? WHERE user_id=?";

    ps = con.prepareStatement(UPDATE_QUERY);

    ps.setString(1, user_name);
    ps.setString(2, email);
    ps.setString(3, password);
    ps.setString(4, gender);
    ps.setString(5, phone_number);
    ps.setString(6, address);
    ps.setString(7, city);
    ps.setInt(8, pincode);
    ps.setInt(9, user_id);

    int result = ps.executeUpdate();

    if(result > 0){
        // ✅ Success
        response.sendRedirect("viewProfile.jsp");
    } else {
        out.println("<h3 style='color:red;text-align:center;'>Update Failed</h3>");
    }

} catch(Exception e){
    e.printStackTrace();
} finally {
    if(ps != null) ps.close();
    if(con != null) con.close();
}
%>
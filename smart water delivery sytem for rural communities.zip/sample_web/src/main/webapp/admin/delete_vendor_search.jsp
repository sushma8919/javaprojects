<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Smart Water | Delete Vendor</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Icons -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

<!-- Font -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">

<style>
body {
	font-family: 'Poppins', sans-serif;
	background: linear-gradient(135deg, #0077b6, #00b4d8);
	color: white;
}

/* Navbar */
.navbar-custom {
	background: rgba(255, 255, 255, 0.1);
	backdrop-filter: blur(10px);
}

.navbar-brand {
	font-weight: 700;
	font-size: 22px;
	color: white;
}

/* Hero */
.search-hero {
	padding-top: 120px;
	text-align: center;
}

/* Title */
.search-title {
	font-size: 3rem;
	font-weight: 800;
	letter-spacing: 1px;
}

/* Subtitle */
.search-subtitle {
	font-size: 1.1rem;
	color: #e0f7fa;
	margin-bottom: 30px;
}

/* Search Box */
.search-box {
	max-width: 600px;
	margin: auto;
}

.search-input {
	border-radius: 50px 0 0 50px;
	padding: 15px;
	border: none;
}

/* Red Delete Button */
.search-btn {
	border-radius: 0 50px 50px 0;
	background: #d00000;
	color: white;
	padding: 15px 25px;
	border: none;
	font-weight: 600;
}

.search-btn:hover {
	background: #900000;
	color: white;
}
</style>

</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
	<div class="container">
		<a class="navbar-brand" href="#">
			<i class="fas fa-tint me-2"></i> Smart Water
		</a>
	</div>
</nav>

<!-- Delete Vendor Section -->
<section class="search-hero">
	<div class="container">

		<h1 class="search-title">
			<i class="fas fa-trash-alt me-2"></i> Delete Vendor
		</h1>

		<p class="search-subtitle">
			Enter the Vendor ID you want to delete
		</p>

		<form action="./deleteven.jsp" method="post">
			<div class="input-group search-box">

				<input type="text" name="vendor_id"
					class="form-control search-input"
					placeholder="Enter Vendor ID" required>

				<input type="submit" value="Delete Vendor" class="search-btn">

			</div>
		</form>

	</div>
</section>

</body>
</html>
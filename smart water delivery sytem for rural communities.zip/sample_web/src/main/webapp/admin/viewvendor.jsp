<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>View Vendors</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background-color: #f8f9fa;
}
.card-vendor {
    border: none;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    padding: 20px;
    border-radius: 12px;
    margin-bottom: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #fff;
}
.card-left { flex: 2; }
.card-middle {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
}
.card-right {
    display: flex;
    align-items: center;
}
.book-btn {
    background-color: #198754;
    color: white;
    padding: 8px 16px;
    border-radius: 6px;
    text-decoration: none;
}
.book-btn:hover {
    background-color: #157347;
}
</style>
</head>

<body>

<%
String GET_ALL_VENDORS = "SELECT * FROM vendor";

try {
    Class.forName("oracle.jdbc.driver.OracleDriver");

    Connection con = DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:XE",
        "batch8",
        "batch8"
    );

    PreparedStatement ps = con.prepareStatement(GET_ALL_VENDORS);
    ResultSet rs = ps.executeQuery();
%>

<div class="container mt-4">
    <h2 class="text-center mb-4">📦 All Vendors</h2>

<%
while(rs.next()){
%>

<div class="card-vendor">

    <!-- Left -->
    <div class="card-left">
    
        <p><b>Vendor ID:</b> <%= rs.getInt("VENDOR_ID") %></p>
        <p><b>Vendor Name:</b> <%= rs.getString("VENDOR_NAME") %></p>
        <p><b>Email:</b> <%= rs.getString("VENDOR_EMAIL") %></p>
        <p><b>Phone:</b> <%= rs.getLong("PHONE_NUMBER") %></p>
        <p><b>Shop Name:</b> <%= rs.getString("SHOP_NAME") %></p>
        <p><b>Rating:</b> ⭐ <%= rs.getInt("RATING") %></p>
    </div>

    <!-- Middle -->
    <div class="card-middle">
        <p><b>Address:</b> <%= rs.getString("SHOP_ADDRESS") %></p>
        <p><b>Location:</b> <%= rs.getString("LOCATION") %></p>
        <p><b>Pincode:</b> <%= rs.getInt("PINCODE") %></p>
    </div>

    <!-- Right (FINAL FIX HERE) -->
    <div class="card-right">
        <a href="view_product.jsp?vendorId=<%= rs.getInt("VENDOR_ID") %>" class="book-btn">
            Book
        </a>
    </div>

</div>

<%
}
%>

</div>

<%
} catch(Exception e){
    out.println("Error: " + e.getMessage());
}
%>

</body>
</html>
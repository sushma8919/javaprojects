<%@ page import="java.sql.*" %>

<%
String user_name = request.getParameter("user_name");
String card_number = request.getParameter("card_number");

// session check
if(session.getAttribute("loggedInuser_id") == null){
    response.sendRedirect("userlogin.jsp");
    return;
}

Connection con = null;
PreparedStatement ps = null;

try {

    Class.forName("oracle.jdbc.driver.OracleDriver");

    con = DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:XE",
        "batch8",
        "batch8"
    );

    // ✅ FIXED TABLE NAME + COLUMNS
    String sql = "INSERT INTO order_booking(booking_id, user_name, card_number) VALUES(order_booking_seq.NEXTVAL, ?, ?)";
    ps = con.prepareStatement(sql);

    ps.setString(1, user_name);
    ps.setString(2, card_number);

    int i = ps.executeUpdate();

    if(i > 0){
        response.sendRedirect("order.jsp?msg=success");
    } else {
        response.sendRedirect("order.jsp?msg=fail");
    }

} catch(Exception e){
    out.println("Error: " + e);

} finally {
    try {
        if(ps != null) ps.close();
        if(con != null) con.close();
    } catch(Exception e){
        out.println(e);
    }
}
%>
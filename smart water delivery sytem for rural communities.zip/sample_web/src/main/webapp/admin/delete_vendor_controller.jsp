<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>

<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Delete Vendor Controller</title>
</head>
<body>

<%
String DELETE_VENDOR = "delete from vendor where vendor_id = ?";
String v_id = request.getParameter("vendor_id");
int vendor_id = Integer.parseInt(v_id);

try {
    Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con = DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8");
    PreparedStatement ps = con.prepareStatement(DELETE_VENDOR);
    ps.setInt(1, vendor_id);

    int i = ps.executeUpdate();

    if (i > 0) {
        out.println("Delete Successfully");
    } else {
        out.println("Delete Failed");
    } 

    ps.close();
    con.close();

} catch (Exception e) {
    e.printStackTrace(); 
}   
%>

</body>
</html>

<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>

<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>updatevendor | sample_web</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../CSS/updatevendor.css"/>

</head>
<body>

<%
String GET_VENDOR_BY_ID = "select * from vendor where vendor_id = ?";
String vendor_id = request.getParameter("vendor_id");

int vendorid=0;
String name="";
String email="";
String password="";
String phonenumber="";
String shop_name="";
String rating="";
String shop_address="";
String location="";
String pincode="";

try{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con = DriverManager.getConnection(
	"jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8");

	PreparedStatement ps = con.prepareStatement(GET_VENDOR_BY_ID);
	ps.setString(1,vendor_id);

	ResultSet rs = ps.executeQuery();

	if(rs.next()) {
		vendorid = rs.getInt("vendor_id");
		name = rs.getString("vendor_name");
		email = rs.getString("vendor_email");
		password = rs.getString("password");
		phonenumber = rs.getString("phone_number");
		shop_name = rs.getString("shop_name");
		rating = rs.getString("rating");
		shop_address = rs.getString("shop_address");
		location = rs.getString("location");
		pincode = rs.getString("pincode");
	}

}catch(Exception e){
	out.println(e);
}
%>

<div class="title-bar">
💧 Smart Water Delivery
</div>

<nav class="navbar navbar-expand-lg navbar-custom">
<div class="container d-flex justify-content-between">

<ul class="navbar-nav flex-row">
<li class="nav-item me-3"><a class="nav-link" href="#">Home</a></li>
<li class="nav-item"><a class="nav-link active" href="#">Vendors</a></li>
</ul>

<a href="login.html" class="btn btn-logout">Logout</a>

</div>
</nav>

<div class="admin-card">

<h3>✏️ Update Vendor</h3>

<form action="vendor_update_controller.jsp" method="post">

<!-- Vendor ID -->
<div class="mb-3">
<label class="form-label">Vendor ID</label>
<input type="text" name="vendor_id" value="<%=vendorid%>" class="form-control" readonly>
</div>

<!-- Name -->
<div class="mb-3">
<label class="form-label">Vendor Name</label>
<input type="text" name="vendor_name" value="<%=name%>" class="form-control" required>
</div>

<!-- Email -->
<div class="mb-3">
<label class="form-label">Email</label>
<input type="email" name="vendor_email" value="<%=email%>" class="form-control" required>
</div>

<!-- Password -->
<div class="mb-3">
<label class="form-label">Password</label>
<input type="text" name="password" value="<%=password%>" class="form-control" required>
</div>

<!-- Phone -->
<div class="mb-3">
<label class="form-label">Phone Number</label>
<input type="text" name="phone_number" value="<%=phonenumber%>" class="form-control" required>
</div>

<!-- Shop Name -->
<div class="mb-3">
<label class="form-label">Shop Name</label>
<input type="text" name="shop_name" value="<%=shop_name%>" class="form-control" required>
</div>
<!-- Shop Cover -->
<div class="mb-3">
<label class="form-label">Shop Cover Image</label>
<input type="file" name="shop_cover" class="form-control">
</div>

<!-- Rating -->
<div class="mb-3">
<label class="form-label">Rating</label>
<input type="number" name="rating" value="<%=rating%>" class="form-control" min="0" max="5">
</div>

<!-- Address -->
<div class="mb-3">
<label class="form-label">Shop Address</label>
<textarea name="shop_address" class="form-control" rows="3" required><%=shop_address%></textarea>
</div>

<!-- Location -->
<div class="mb-3">
<label class="form-label">Location</label>
<input type="text" name="location" value="<%=location%>" class="form-control" required>
</div>

<!-- Pincode -->
<div class="mb-3">
<label class="form-label">Pincode</label>
<input type="text" name="pincode" value="<%=pincode%>" class="form-control" required>
</div>

 <!-- UPDATE & CLEAR BUTTONS CENTERED -->
    <div class="d-flex justify-content-center gap-3 mt-3">
      <button type="submit" class="btn btn-primary">Update</button>
      <button type="reset" class="btn btn-secondary">Clear</button>
    </div>


</form>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
```

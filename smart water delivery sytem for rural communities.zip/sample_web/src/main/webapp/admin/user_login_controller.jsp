<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>user controller| sample_web</title>
</head>
<body>
<%
String email = request.getParameter("email");
String password = request.getParameter("password");

Class.forName("oracle.jdbc.driver.OracleDriver");

Connection con = DriverManager.getConnection(
"jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8"
);

PreparedStatement ps = con.prepareStatement(
"SELECT * FROM users1 WHERE email=? AND password=?"
);

ps.setString(1, email);
ps.setString(2, password);

ResultSet rs = ps.executeQuery();

if(rs.next()){

    session.setAttribute("loggedInuser_id", rs.getInt("user_id"));
    session.setAttribute("loggedInuser_name", rs.getString("user_name"));
    session.setAttribute("loggedInuser_email", rs.getString("email"));

    response.sendRedirect("./manageusers.jsp");
}
else{
    out.println("Invalid Login");
}

con.close();
%>
</body>
</html>
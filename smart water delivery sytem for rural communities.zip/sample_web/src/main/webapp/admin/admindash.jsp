<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>admin dash | sample_web</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../CSS/admindash.css"/>
</head>
<body>
<div class="container-fluid">
<div class="row">

<!-- SIDEBAR -->
<div class="col-md-2 sidebar">
    <h4 class="text-center">💧 Admin</h4>
    <hr>
     
   
    <a href=userdashboard.jsp>👤user menu</a>
    <a href=manageusers.jsp>👤 Manage Users</a>
    <a href=vendordash.jsp>🏪  Vendors menu</a>
   
   <!--  <a href="login.jsp">🚪 Logout</a> -->
</div>

<!-- MAIN CONTENT -->
<div class="col-md-10 main">

    <!-- TOPBAR -->
    <div class="topbar mb-4">

        <!-- LEFT -->
        <span style="position:absolute; left:20px;">
            Welcome Admin 👨‍💼
        </span>

        <!-- CENTER -->
        <h5 class="text-center m-0 fw-bold">
            💧 Smart Water
        </h5>

            </div>

   
    <!-- <div class="row">

        <div class="col-md-4">
            <div class="card p-3">
                <h6>Total Users</h6>
                <h3>10</h3>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card p-3">
                <h6>Total Vendors</h6>
                <h3>5</h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3">
                <h6>Total orders</h6>
                <h3>5</h3>
            </div>
        </div>

                </div> 
 -->
    </div>

   </div>
</div>

</body>
</html>
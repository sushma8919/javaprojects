<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Product Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

/* Blue Background */
body {
    background: linear-gradient(135deg, #0d6efd, #0a58ca);
    font-family: Arial;
}

/* Title */
.title-bar {
    background-color: #0a58ca;
    color: white;
    padding: 15px;
    text-align: center;
    font-size: 22px;
    font-weight: bold;
}

/* Navbar */
.navbar-custom {
    background-color: #084298;
}

.navbar-custom .nav-link {
    color: white;
}

/* Dashboard Box */
.dashboard-box {
    background: white;
    max-width: 500px;
    margin: 60px auto;
    padding: 30px;
    border-radius: 15px;
    text-align: center;
    box-shadow: 0 10px 25px rgba(0,0,0,0.3);
}

/* Buttons */
.btn-custom {
    width: 100%;
    margin-bottom: 15px;
    padding: 10px;
    font-size: 16px;
    border-radius: 8px;
}

.btn-add { background-color: #198754; color: white; }
.btn-view { background-color: #0d6efd; color: white; }
.btn-update { background-color: #ffc107; color: black; }
.btn-delete { background-color: #dc3545; color: white; }

</style>

</head>
<body>

<!-- Title -->
<div class="title-bar">
💧 Smart Water Delivery System - Product Dashboard
</div>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-custom">
  <div class="container d-flex justify-content-between">
    <ul class="navbar-nav flex-row">
      <li class="nav-item me-3"><a class="nav-link" href="#">Home</a></li>
      <li class="nav-item"><a class="nav-link active" href="#">Products</a></li>
    </ul>
    <a href="login.html" class="btn btn-danger">Logout</a>
  </div>
</nav>

<!-- Dashboard Actions -->
<div class="dashboard-box">

    <h3 class="mb-4">📦 Product Management</h3>
    

    <!-- Add -->
    <a href="add_product.jsp" class="btn btn-add btn-custom">➕ Add Product</a>

    <!-- Update -->
    <a href="product_search.jsp" class="btn btn-update btn-custom">✏️ Update Product</a>
 
    <!-- Delete -->
    <a href="delete_product_search.jsp" class="btn btn-delete btn-custom">❌ Delete Product</a>
<!-- <!-- View
    <a href="view_product.jsp" class="btn btn-view btn-custom">👁 View Products</a>
 --> 
</div>

</body>
</html>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>


<%
String vidParam = request.getParameter("vendor_id");
Integer selectedVendor = null;

if(vidParam != null){
    selectedVendor = Integer.parseInt(vidParam);
}
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Vendor Products</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<h2 style="text-align:center;">📦 Vendor Products</h2>

<%
Connection con = null;

try{
    Class.forName("oracle.jdbc.driver.OracleDriver");
    con = DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8");

    PreparedStatement ps;

    /* 🔥 IF VENDOR SELECTED → FILTER */
    if(selectedVendor != null){
        ps = con.prepareStatement(
            "SELECT * FROM products WHERE vendor_id=?"
        );
        ps.setInt(1, selectedVendor);
    } 
    /* 🔥 ELSE → SHOW NOTHING OR ALL (optional) */
    else{
        ps = con.prepareStatement(
            "SELECT * FROM products"
        );
    }

    ResultSet rs = ps.executeQuery();
%>

<table class="table table-bordered" style="width:85%; margin:auto;">
<tr>
    <th>Product ID</th>
    <th>Vendor ID</th>
    <th>Product Name</th>
    <th>Description</th>
    <th>Price</th>
    <th>Quantity</th>
</tr>

<%
while(rs.next()){
%>

<tr>
    <td><%= rs.getInt("PRODUCT_ID") %></td>
    <td><%= rs.getInt("VENDOR_ID") %></td>
    <td><%= rs.getString("PRODUCT_NAME") %></td>
    <td><%= rs.getString("DESCRIPTION") %></td>
    <td><%= rs.getDouble("PRICE") %></td>
    <td><%= rs.getInt("QUANTITY") %></td>
</tr>

<%
}
%>

</table>

<%
}catch(Exception e){
    out.println(e);
}
%>

</body>
</html>
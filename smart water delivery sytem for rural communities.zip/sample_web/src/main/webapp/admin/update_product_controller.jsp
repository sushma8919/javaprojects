<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>

<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>update controller</title>
</head>
<body>

<% 

if(session.getAttribute("vendor_id") == null){
    response.sendRedirect("login.html");
    return;
}


int vendor_id = (Integer)session.getAttribute("vendor_id");
String vendor_name = (String)session.getAttribute("vendor_name");


String products_id = request.getParameter("product_id");
int product_id = Integer.parseInt(products_id);

String product_name = request.getParameter("product_name");
String description = request.getParameter("description");

String prices = request.getParameter("price");
double price = Double.parseDouble(prices);

String quantitys = request.getParameter("quantity");
int quantity = Integer.parseInt(quantitys);


String UPDATE_PRODUCT = "UPDATE PRODUCTS SET product_name=?, description=?, price=?, quantity=? WHERE product_id=? AND vendor_id=?";

try {

    Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con = DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:XE", "batch8", "batch8");

    PreparedStatement ps = con.prepareStatement(UPDATE_PRODUCT);

    ps.setString(1, product_name);
    ps.setString(2, description);
    ps.setDouble(3, price);
    ps.setInt(4, quantity);
    ps.setInt(5, product_id);
    ps.setInt(6, vendor_id); 
    int i = ps.executeUpdate();

    if (i > 0) {
%>
        <h3 style="color:green;text-align:center;">Product Updated Successfully</h3>
<%
    } else {
%>
        <h3 style="color:red;text-align:center;">Update Failed or Unauthorized</h3>
<%
    }

} catch (Exception e) {
    out.println(e);
}
%>

</body>
</html>
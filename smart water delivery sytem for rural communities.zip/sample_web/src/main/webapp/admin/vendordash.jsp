<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>vendordash | sample_web</title>
<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="../CSS/vendordash.css"/>
</head>
<body>
<body>

<div class="title-bar">
💧 Smart Water Delivery | vendor menu 
</div>

<div class="menu-card text-center">

<h4 class="mb-4">👤 Vendor Management</h4>

<!-- DROPDOWN MENU -->
<div class="dropdown">
  <button class="btn btn-primary dropdown-toggle w-100" type="button" data-bs-toggle="dropdown">
    Manage Vendors
  </button>
<ul class="dropdown-menu w-100 text-center">
    <li><a class="dropdown-item" href="addvendor.jsp">➕ Add Vendor</a></li>
    <li><a class="dropdown-item" href="vendor_update_search.jsp">✏️ Update Vendor</a></li>
    <li><a class="dropdown-item" href="delete_vendor_search.jsp">❌ Delete Vendor</a></li>
    <li><a class="dropdown-item" href="viewvendor.jsp">📋 View All Vendors</a></li>
  </ul>
  </div>

</div>

<!-- LOGOUT -->
<div class="logout-area">
<a href="login.html" class="btn btn-logout mt-3">Logout</a>
</div>

<!-- Bootstrap JS (important for dropdown) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>


</body>
</html>
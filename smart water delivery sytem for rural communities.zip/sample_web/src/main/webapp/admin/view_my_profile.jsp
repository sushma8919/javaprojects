<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>

<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>view my profile</title>

<style>
body {
    font-family: Arial;
    background-color: #e6f0ff;
}

.title {
    text-align: center;
    color: #0047b3;
    font-size: 26px;
    margin-top: 20px;
    font-weight: bold;
}

table {
    border-collapse: collapse;
    width: 50%;
    margin: 40px auto;
    background-color: white;
    box-shadow: 0px 0px 10px gray;
}

td {
    padding: 12px;
    border: 1px solid #ccc;
}

tr:nth-child(even) {
    background-color: #f2f7ff;
}

tr:hover {
    background-color: #d9e6ff;
}

/* Back Button */
.back-btn {
    background-color: #0047b3;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

.back-btn:hover {
    background-color: #003366;
}
</style>

</head>
<body>

<div class="title">My Profile</div>

<!-- Back Button -->
<div style="text-align:center; margin-top:10px;">
    <button onclick="history.back()" class="back-btn">⬅ Back</button>
</div>

<%
String GET_USER_BY_ID = "select * from users1 where user_id = ?";
Integer user_id = (Integer) session.getAttribute("loggedInuser_id");
try {
    Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con = DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8");

    PreparedStatement ps = con.prepareStatement(GET_USER_BY_ID);

    
    ps.setInt(1, user_id);

    ResultSet rs = ps.executeQuery();
    if(rs.next()) {
%>

<table>
<tr>
   <td>User Id</td><td><%=rs.getInt(1)%></td>
</tr>
<tr>
   <td>User Name</td><td><%=rs.getString(2)%></td>
</tr>
<tr>
   <td>Email</td><td><%=rs.getString(3)%></td>
</tr>
<tr>
   <td>Password</td><td><%=rs.getString(4)%></td>
</tr>
<tr>
   <td>Gender</td><td><%=rs.getString(5)%></td>
</tr>
<tr>
   <td>Phone Number</td><td><%=rs.getLong(6)%></td>
</tr>
<tr>
   <td>Address</td><td><%=rs.getString(7)%></td>
</tr>
<tr>
   <td>City</td><td><%=rs.getString(8)%></td>
</tr>
<tr>
   <td>Pincode</td><td><%=rs.getInt(9)%></td>
</tr>
</table>

<%
    } else {
%>
    <h3 style="text-align:center; color:red;">No User Found</h3>
<%
    }

} catch(Exception e) {
    e.printStackTrace();
}
%>

</body>
</html>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>


<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<title>User Registration | Smart Water</title>

<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
  min-height:100vh;
  display:flex;
  justify-content:center;
  align-items:center;
  background:linear-gradient(to right,#00b4d8,#90e0ef);
  font-family:'Segoe UI',sans-serif;
}

.register-card{
  width:420px;
  padding:30px;
  border-radius:12px;
  background:white;
  box-shadow:0px 5px 20px rgba(0,0,0,0.2);
}

/* FIXED TITLE */
.title{
  text-align:center;
  color:#023e8a;   /* darker blue */
  margin-bottom:20px;
  font-weight:bold;
  font-size:26px;
}

</style>

</head>

<body>

<div class="register-card">

<!-- TITLE -->
<h3 class="title">👤 New User</h3>

<form action="register_controller.jsp" method="post">

<div class="mb-3">
<label>Name</label>
<input type="text" name="name" class="form-control" required>
</div>

<div class="mb-3">
<label>Email</label>
<input type="email" name="email" class="form-control" required>
</div>

<div class="mb-3">
<label>Create Password</label>
<input type="password" name="password" class="form-control" required>
</div>

<div class="mb-3">
<label>Gender</label>
<select name="gender" class="form-control" required>
<option value="">Select gender</option>
<option value="male">Male</option>
<option value="female">Female</option>
<option value="other">Other</option>
</select>
</div>

<div class="mb-3">
<label>Phone Number</label>
<input type="tel" name="phonenumber" class="form-control" required>
</div>

<div class="mb-3">
<label>Address</label>
<textarea name="address" class="form-control" rows="3" required></textarea>
</div>

<div class="mb-3">
<label>City</label>
<input type="text" name="city" class="form-control" required>
</div>

<div class="mb-3">
<label>Pincode</label>
<input type="text" name="pincode" class="form-control" required>
</div>

<div class="d-grid">
<button type="submit" class="btn btn-primary">Register</button>
</div>

</form>

<div class="text-center mt-3">
<a href="./userlogin.jsp">Login</a>
</div>

</div>

</body>
</html>
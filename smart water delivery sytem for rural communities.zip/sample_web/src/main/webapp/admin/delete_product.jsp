<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>

<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Delete Product | Smart Water Delivery</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../CSS/deleteven.css"/>

<style>
.btn-delete {
    background-color: #dc3545;
    color: white;
}
.btn-delete:hover {
    background-color: #a71d2a;
}
.btn-back {
    background-color: #6c757d;
    color: white;
}
.btn-back:hover {
    background-color: #5a6268;
}
</style>
</head>
<body>

<%
/* 🔒 Session Check */
if(session.getAttribute("vendor_id") == null){
    response.sendRedirect("login.html");
    return;
}

/* 📥 Session values */
int vendorid = (Integer)session.getAttribute("vendor_id");
String vendor_name = (String)session.getAttribute("vendor_name");

/* 🔍 Secure Query */
String GET_PRODUCT_BY_ID = "select * from products where product_id=? and vendor_id=?";
String product_id = request.getParameter("product_id");

int productid=0;
String product_name="";
String description="";
Double price = 0.0;
int quantity=0;

try{
    Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con = DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8");

    PreparedStatement ps = con.prepareStatement(GET_PRODUCT_BY_ID);
    ps.setString(1, product_id);
    ps.setInt(2, vendorid); // 🔥 security

    ResultSet rs = ps.executeQuery();

    if(rs.next()) {
        productid = rs.getInt("product_id");
        product_name = rs.getString("product_name");
        description = rs.getString("description");
        price = rs.getDouble("price");
        quantity = rs.getInt("quantity");
    } else {
%>
        <h3 style="color:red;text-align:center;">Unauthorized Access</h3>
<%
        return;
    }

}catch(Exception e){
    out.println(e);
}
%>

<!-- TITLE -->
<div class="title-bar">
💧 Smart Water Delivery System for Rural Communities
</div>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-custom">
  <div class="container d-flex justify-content-between">
    <ul class="navbar-nav flex-row">
      <li class="nav-item me-3"><a class="nav-link" href="#">Home</a></li>
      <li class="nav-item"><a class="nav-link active" href="#">Products</a></li>
    </ul>
    <a href="login.html" class="btn btn-danger">Logout</a>
  </div>
</nav>

<!-- CARD -->
<div class="admin-card">
<h3>🗑 Delete Product</h3>

<form action="delete_product_controller.jsp" method="post">

<!-- Product ID -->
<div class="mb-3">
    <label class="form-label">Product ID</label>
    <input type="text" value="<%=productid%>" class="form-control" readonly>
    <input type="hidden" name="product_id" value="<%=productid%>">
</div>

<!-- Vendor ID (Session) -->
<div class="mb-3">
<label class="form-label">Vendor ID</label>
<input type="number" value="<%=vendorid%>" class="form-control" readonly>
</div>

<!-- Vendor Name (Session) -->
<div class="mb-3">
<label class="form-label">Vendor Name</label>
<input type="text" value="<%=vendor_name%>" class="form-control" readonly>
</div>

<!-- Product Name -->
<div class="mb-3">
<label class="form-label">Product Name</label>
<input type="text" value="<%=product_name%>" class="form-control" readonly>
</div>

<!-- Description -->
<div class="mb-3">
<label class="form-label">Description</label>
<textarea class="form-control" rows="3" readonly><%= description %></textarea>
</div>

<!-- Price -->
<div class="mb-3">
<label class="form-label">Price (₹)</label>
<input type="number" value="<%=price%>" class="form-control" readonly>
</div>

<!-- Quantity -->
<div class="mb-3">
<label class="form-label">Quantity</label>
<input type="number" value="<%=quantity%>" class="form-control" readonly>
</div>

<!-- BUTTONS -->
<div class="d-flex justify-content-center gap-3 mt-4">
    <button type="submit" class="btn btn-delete"
        onclick="return confirm('Are you sure you want to delete this product?');">
        Delete Product
    </button>

    <button type="button" class="btn btn-back" onclick="history.back()">Back</button>
</div>

</form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
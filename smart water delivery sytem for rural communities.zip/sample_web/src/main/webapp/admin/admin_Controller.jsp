<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>admin controller| sample_web</title>
</head>
<body>
<% String email = request.getParameter("email");
String password = request.getParameter("password");
System.out.println("successfully");
try {
		
	Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8");
		PreparedStatement ps = con.prepareStatement("Select * from adminn where email=? and password=? ");
		ps.setString(1, email);
		ps.setString(2, password);
		ResultSet rs = ps.executeQuery();
		if(rs.next()){
			
			int loggedInadmin_id = rs.getInt(1);
			String loggedInfull_name = rs.getString(2);
			String loggedInemail = rs.getString(3);
			
			session.setAttribute("loggedInadmin_id", loggedInadmin_id);
			session.setAttribute("loggedInfull_name", loggedInfull_name);
			session.setAttribute("loggedInemail", loggedInemail );
			
			response.sendRedirect("./admindash.jsp");
		}
else{

	
	response.sendRedirect("./admin_login.jsp");

}
		con.close();

}catch(Exception e){e.printStackTrace();}
		%>
</body>
</html>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>


<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<% 
String name = request.getParameter("vendor_name");
String email = request.getParameter("vendor_email");
String password = request.getParameter("password");
String phonenumber = request.getParameter("phone_number");
String shop_name = request.getParameter("shop_name");
String rating = request.getParameter("rating");

String shop_address = request.getParameter("shop_address");
String location = request.getParameter("location");
String pincode = request.getParameter("pincode");

System.out.println("Name: " + name);
System.out.println("Email: " + email);
System.out.println("Password: " + password);
System.out.println("Phone: " + phonenumber);
System.out.println("Shop Name: " + shop_name);
System.out.println("Rating: " + rating);
System.out.println("Address: " + shop_address);
System.out.println("Location: " + location);
System.out.println("Pincode: " + pincode);
String UPDATE_VENDOR = "INSERT INTO VENDOR(vendor_id,vendor_name,vendor_email,password,phone_number,shop_name,shop_cover,rating,shop_address,location,pincode) VALUES(vendor_seq.NEXTVAL,?,?,?,?,?,?,?,?,?,?)";
try {

	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "batch8", "batch8");
	PreparedStatement ps = con.prepareStatement(UPDATE_VENDOR);
	

	ps.setString(1, name);
	ps.setString(2, email);
	ps.setString(3, password);
	ps.setString(4, phonenumber);
	ps.setString(5, shop_name);
	ps.setNull(6, java.sql.Types.BLOB);
	ps.setString(7, rating);
	ps.setString(8, shop_address);
	ps.setString(9, location);
	ps.setString(10, pincode);

	ps.executeUpdate();
    int i = ps.executeUpdate();

	if (i > 0) {
		out.println("updated Successfully");

	} else {
		out.println("updated Failed");
	}

} catch (Exception e) {
	e.printStackTrace();
}
	%>
</body>
</html>
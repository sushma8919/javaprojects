<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>View Products</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../CSS/view.css"/>
</head>
<body>
<!-- VIEW CART -->
<div class="top-right">
    <a href="viewallcart.jsp">
        <button class="cart-btn">🛒 View Cart</button>
    </a>
</div>

<%
   
    String vid = request.getParameter("vendorId");

    if(vid == null){
        out.println("Invalid Vendor!");
        return;
    }

    int vendorId = Integer.parseInt(vid);

    String GET_VENDOR_PRODUCTS = "SELECT * FROM products WHERE vendor_id=?";

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        Connection con = DriverManager.getConnection(
            "jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8");

        PreparedStatement ps = con.prepareStatement(GET_VENDOR_PRODUCTS);
        ps.setInt(1, vendorId);

        ResultSet rs = ps.executeQuery();
%>

<!-- TITLE -->
<div class="title-bar">
  🛒 Products List
</div>

<!-- TABLE -->
<div class="admin-card">
  <h3>📦 Vendor Products</h3>

<table class="table-custom table table-striped table-bordered">

<%-- <tr>
    <th>Product ID</th>
    <th>Vendor ID</th>
    <th>Vendor Name</th>
    <th>Product Name</th>
    <th>Description</th>
    <th>Price</th>
    <th>Quantity</th>
     <th>cart</th>
  
    
</tr>

<%
boolean hasData = false;

while(rs.next()) {
    hasData = true;
%>
<tr>
    <td><%= rs.getInt("PRODUCT_ID") %></td>
    <td><%= rs.getInt("VENDOR_ID") %></td>
    <td><%= rs.getString("VENDOR_NAME") %></td>
    <td><%= rs.getString("PRODUCT_NAME") %></td>
    <td><%= rs.getString("DESCRIPTION") %></td>
    <td><%= rs.getDouble("PRICE") %></td>
    <td><%= rs.getInt("QUANTITY") %></td>
    <td>
<a href="addProductCart.jsp?product_id=<%=rs.getInt("PRODUCT_ID")%>
&product_name=<%=rs.getString("PRODUCT_NAME")%>
&quantity=1
&price=<%=rs.getDouble("PRICE")%>" 
class="btn btn-warning">

Add to Cart
</a>
</td>
</tr>
<%
}
%> --%>
<!-- TABLE -->

<table class="table-custom table table-striped table-bordered">

<tr>
    <th>Product ID</th>
    <th>Vendor ID</th>
    <th>Vendor Name</th>
    <th>Product Name</th>
    <th>Description</th>
    <th>Price</th>
    <th>Quantity</th>
</tr>

<%
while(rs.next()) {
%>
<tr>
    <td><%= rs.getInt("PRODUCT_ID") %></td>
    <td><%= rs.getInt("VENDOR_ID") %></td>
    <td><%= rs.getString("VENDOR_NAME") %></td>
    <td><%= rs.getString("PRODUCT_NAME") %></td>
    <td><%= rs.getString("DESCRIPTION") %></td>
    <td><%= rs.getDouble("PRICE") %></td>
    <td><%= rs.getInt("QUANTITY") %></td>
</tr>
<%
}
%>

</table>

<div class="mt-4 text-center">
    <a href="./viewvendor.jsp" class="btn btn-success">Back</a>
</div>

</div>
</table>


<%-- <%
if(!hasData){
%>
    <h5 style="color:red; text-align:center;">No Products Available for this Vendor</h5>
<%
}
%>

</div> --%>

<%
    } catch(Exception e){
        out.println("<h3 style='color:red;'>Error: "+e+"</h3>");
    }
%>

</body>
</html>
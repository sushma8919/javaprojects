<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
if(session.getAttribute("loggedInuser_id") == null){
    response.sendRedirect("userlogin.jsp");
    return;
}

String user_name = session.getAttribute("loggedInuser_name").toString();
%>

<!DOCTYPE html>
<html>
<head>
    <title>Booking Page</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body{
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .card-box{
            width: 450px;
            padding: 30px;
            border-radius: 20px;
            background: #ffffff;
            box-shadow: 0px 10px 30px rgba(0,0,0,0.3);
        }

        .title{
            text-align:center;
            margin-bottom:20px;
            font-weight:bold;
            color:#1e3c72;
        }

        .btn-blue{
            background: #1e3c72;
            color: white;
        }

        .btn-blue:hover{
            background: #16325c;
            color: white;
        }

        label{
            font-weight: 500;
            color:#333;
        }
    </style>
</head>

<body>

<div class="card-box">

    <h3 class="title">Booking </h3>

    <form action="order_controller.jsp" method="post">

        <div class="mb-3">
            <label class="form-label">User Name</label>
            <input type="text" name="user_name" class="form-control" value="<%=user_name%>" readonly>
        </div>

        <div class="mb-3">
            <label class="form-label">Card Number</label>
            <input type="text" name="card_number" class="form-control" placeholder="Enter card number" required>
        </div>

        <button type="submit" class="btn btn-blue w-100">Book Now</button>

    </form>

</div>

</body>
</html>
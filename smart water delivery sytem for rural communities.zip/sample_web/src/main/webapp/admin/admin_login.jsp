<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>admin Login | Smart Water</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">

<style>
body {
    font-family: 'Poppins', sans-serif;
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(90deg, #5f6ad4, #7a86f7);
}

/* LOGIN CARD */
.login-card {
    background: white;
    padding: 50px;
    border-radius: 20px;
    width: 420px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
}

/* TITLE */
.login-title {
    text-align: center;
    font-size: 30px;
    font-weight: 700;
    color: #5f6ad4;
    margin-bottom: 10px;
}

.login-sub {
    text-align: center;
    color: #666;
    margin-bottom: 30px;
}

/* INPUT */
.form-control, .form-select {
    padding: 12px;
    border-radius: 12px;
}

/* BUTTON */
.btn-login {
    background: linear-gradient(90deg, #5f6ad4, #7a86f7);
    border: none;
    border-radius: 30px;
    padding: 12px;
    font-size: 18px;
    font-weight: 600;
    color: white;
}

.btn-login:hover {
    opacity: 0.9;
}

/* REGISTER TEXT */
.register-text {
    text-align: center;
    margin-top: 18px;
}

.register-text a {
    text-decoration: none;
    font-weight: 600;
    color: #5f6ad4;
}
</style>
</head>

<body>

<div class="login-card">

    <div class="login-title">Smart Water Login</div>

    <div class="login-sub">Secure access to the platform</div>

    <form action="admin_Controller.jsp" method="post">

        <label class="form-label">Email Address</label>
        <input type="email" class="form-control mb-3" name="email" placeholder="Enter email" required>

        <label class="form-label">Password</label>
        <input type="password" class="form-control mb-4" name="password" placeholder="Enter password" required>

        <button type="submit" class="btn btn-login w-100">Login</button>

        

    </form>

</div>

</body>
</html>
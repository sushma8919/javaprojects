
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Smart Water | User Dashboard</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Custom CSS -->
<link rel="stylesheet" href="../CSS/userdashboard.css"/>

<style>
/* HORIZONTAL LAYOUT */
.menu-container {
    display: flex;
    justify-content: center;
    gap: 20px;
    flex-wrap: wrap;
    margin-top: 40px;
}

.menu-card {
    width: 250px;
    padding: 20px;
    border-radius: 12px;
    background: #f8f9fa;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}

.title-bar {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    padding: 15px;
    background: #0d6efd;
    color: white;
}

.logout-area {
    text-align: center;
    margin-top: 30px;
}

.btn-logout {
    background: red;
    color: white;
}
</style>

</head>

<body>

<div class="title-bar">
💧 Smart Water Delivery | User Menu
</div>

<div class="menu-container">

<!-- PROFILE -->
<div class="menu-card text-center">
<h4 class="mb-4">👤 My Profile</h4>
<div class="dropdown">
  <button class="btn btn-primary dropdown-toggle w-100" data-bs-toggle="dropdown">
    Click Here
  </button>
  <ul class="dropdown-menu w-100 text-center">
    <li><a class="dropdown-item" href="view_my_profile.jsp">👁️ View Profile</a></li>
   <!--  <li><a class="dropdown-item" href="update_profile.jsp">✏️ Update Profile</a></li> -->
  </ul>
</div>
</div>

<!-- BOOKINGS -->
<div class="menu-card text-center">
<h4 class="mb-4">📚 Bookings</h4>
<div class="dropdown">
  <button class="btn btn-primary dropdown-toggle w-100" data-bs-toggle="dropdown">
    Click Here
  </button>
  <ul class="dropdown-menu w-100 text-center">
    <li><a class="dropdown-item" href="order.jsp">📚 View All Bookings</a></li>
  </ul>
</div>
</div>

<!-- <!-- WATER BOOKINGS
<div class="menu-card text-center">
<h4 class="mb-4">💧 Water Bookings</h4>
<div class="dropdown">
  <button class="btn btn-primary dropdown-toggle w-100" data-bs-toggle="dropdown">
    Click Here
  </button>
  <ul class="dropdown-menu w-100 text-center">
    <li><a class="dropdown-item" href="#">📝 Start Bookings</a></li>
  </ul>
</div>
</div> --> -->

<!-- VENDORS -->
<div class="menu-card text-center">
<h4 class="mb-4">👥 Vendors</h4>
<div class="dropdown">
  <button class="btn btn-primary dropdown-toggle w-100" data-bs-toggle="dropdown">
    Click Here
  </button>
  <ul class="dropdown-menu w-100 text-center">
    <li><a class="dropdown-item" href="viewvendor.jsp">👁️ View Vendors</a></li>
  </ul>
</div>
</div>

</div>

<!-- LOGOUT -->
<div class="logout-area">
<a href="userlogin.jsp" class="btn btn-logout mt-3">Logout</a>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
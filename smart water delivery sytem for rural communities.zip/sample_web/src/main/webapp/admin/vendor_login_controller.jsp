<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>

<%@ page contentType="text/html; charset=ISO-8859-1" %>



<%
String email = request.getParameter("vendor_email"); 
String password = request.getParameter("password");

try {
    Class.forName("oracle.jdbc.driver.OracleDriver");

    Connection con = DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:XE",
        "batch8",
        "batch8"
    );

    PreparedStatement ps = con.prepareStatement(
        "SELECT * FROM vendor WHERE vendor_email=? AND password=?"
    );

    ps.setString(1, email);
    ps.setString(2, password);

    ResultSet rs = ps.executeQuery();

    if(rs.next()){

        
        
        session.setAttribute("vendor_id", rs.getInt("vendor_id"));
        session.setAttribute("vendor_name", rs.getString("vendor_name"));
        session.setAttribute("vendor_email", rs.getString("vendor_email"));

        response.sendRedirect("productdashboard.jsp");

    } else {
%>
        <h3 style="color:red;text-align:center;">Invalid Login</h3>
        <div style="text-align:center;">
            <a href="vendor_login.jsp">Try Again</a>
        </div>
<%
    }

    con.close();

} catch(Exception e){
    out.println(e);
}
%>
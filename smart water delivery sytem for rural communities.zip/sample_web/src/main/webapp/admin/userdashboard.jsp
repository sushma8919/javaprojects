<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>user dashboard | sample_web</title>
<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../CSS/userdashboard.css"/>

</head>
<body>
<div class="title-bar">
💧 Smart Water Delivery 
</div>

<div class="menu-card text-center">

<h4 class="mb-4">👤 User Management</h4>

<!-- DROPDOWN MENU -->
<div class="dropdown">
  <button class="btn btn-primary dropdown-toggle w-100" type="button" data-bs-toggle="dropdown">
    Manage Users
  </button>

  <ul class="dropdown-menu w-100 text-center">
    <li><a class="dropdown-item" href="register.jsp">➕ Add User</a></li>
    <li><a class="dropdown-item" href="searchuser.jsp">✏️ Update User</a></li>
    <li><a class="dropdown-item" href="../user/deletesearchuser.jsp">❌ Delete User</a></li>
    <li><a class="dropdown-item" href="../user/view.jsp">📋 View All Users</a></li>
    
  </ul>
</div>

</div>

<!-- LOGOUT -->
<div class="logout-area">
<a href="login.html" class="btn btn-logout mt-3">Logout</a>
</div>

<!-- Bootstrap JS (important for dropdown) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>


</body>
</html>
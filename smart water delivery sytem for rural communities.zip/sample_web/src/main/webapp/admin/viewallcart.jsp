<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>

<%@ page contentType="text/html; charset=UTF-8" %>

<%
if(session.getAttribute("loggedInuser_id") == null){
    response.sendRedirect("userlogin.jsp");
    return;
}

int userId = Integer.parseInt(session.getAttribute("loggedInuser_id").toString());
String userName = session.getAttribute("loggedInuser_name").toString();

double totalAmount = 0;

Connection con = null;
PreparedStatement ps = null;
ResultSet rs = null;

try {

    Class.forName("oracle.jdbc.driver.OracleDriver");

    con = DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:XE",
        "batch8",
        "batch8"
    );

    String sql = "SELECT CART_ID, USER_ID, PRODUCT_ID, PRODUCT_NAME, PRICE, QUANTITY " +
                 "FROM product_cart WHERE user_id=?";

    ps = con.prepareStatement(sql);
    ps.setInt(1, userId);

    rs = ps.executeQuery();
%>

<!DOCTYPE html>
<html>
<head>
<title>My Cart</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#f4f6f9;
}

.title-bar{
    background: linear-gradient(90deg,#11998e,#38ef7d);
    color:white;
    text-align:center;
    padding:15px;
    font-size:22px;
    font-weight:bold;
}

.container-box{
    width:90%;
    margin:auto;
    background:white;
    padding:20px;
    border-radius:10px;
    box-shadow:0px 0px 10px #ccc;
}

.table th{
    background:#343a40;
    color:white;
    text-align:center;
}

.table td{
    text-align:center;
}

.total-box{
    text-align:right;
    margin-top:15px;
    font-size:22px;
    font-weight:bold;
    color:green;
}
</style>
</head>

<body>

<div class="title-bar">
🛒 <%= userName %> (ID: <%= userId %>) - My Cart
</div>

<div class="container-box">

<table class="table table-bordered table-striped">

<tr>
    <th>Cart ID</th>
    <th>User ID</th>
    <th>User Name</th>
    <th>Product ID</th>
    <th>Product Name</th>
    <th>Price</th>
    <th>Quantity</th>
    <th>Total</th>
</tr>

<%
while(rs.next()) {

    int qty = rs.getInt("QUANTITY");
    double price = rs.getDouble("PRICE");
    double rowTotal = qty * price;

    totalAmount += rowTotal;
%>

<tr>
    <td><%= rs.getInt("CART_ID") %></td>

    <!-- FIXED USER ID -->
    <td><%= userId %></td>

    <!-- FIXED USER NAME -->
    <td><%= userName %></td>

    <td><%= rs.getInt("PRODUCT_ID") %></td>
    <td><%= rs.getString("PRODUCT_NAME") %></td>
    <td>₹<%= price %></td>
    <td><%= qty %></td>
    <td>₹<%= rowTotal %></td>
</tr>

<% } %>

</table>

<div class="total-box">
💰 Grand Total: ₹ <%= totalAmount %>
</div>

</div>

</body>
</html>

<%
} catch(Exception e){
    out.println("<h3 style='color:red'>Error: " + e.getMessage() + "</h3>");
} finally {
    if(rs != null) rs.close();
    if(ps != null) ps.close();
    if(con != null) con.close();
}
%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>User Login | Sample Web</title>

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="./CSS/userlogin.css"/>
<style>
body {
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background: linear-gradient(to right, #1e6de0, #6aa8ff);
    font-family: 'Segoe UI', sans-serif;
}

.login-card {
    background: #fff;
    padding: 40px;
    border-radius: 15px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    width: 350px;
    text-align: center;
}

.login-card h2 {
    margin-bottom: 30px;
    color: #1e6de0;
}

.login-card .form-control {
    margin-bottom: 20px;
    border-radius: 10px;
}

.login-card .btn-primary {
    width: 100%;
    border-radius: 10px;
    margin-bottom: 15px;
}

.login-card a {
    display: block;
    margin-top: 10px;
    text-decoration: none;
    color: #1e6de0;
}

.login-card a:hover {
    text-decoration: underline;
}
</style>
</head>
<body>

<div class="login-card">
    <h2>User Login</h2>
    <form action="user_login_controller.jsp" method="post">
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" name="email" class="form-control" id="email" placeholder="Enter your email" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" name="password" class="form-control" id="password" placeholder="Enter your password" required>
        </div>
        <button type="submit" class="btn btn-primary">Login</button>
    </form>
    
    <a href=register.jsp>Register here</a>
    <a href=admin_login.jsp>Admin Login</a>
    <a href="vendor_login.jsp">Vendor Login</a>
</div>

<!-- Bootstrap JS (Optional) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
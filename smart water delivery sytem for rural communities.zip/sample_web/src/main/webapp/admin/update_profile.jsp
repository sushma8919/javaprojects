<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>

<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Update User Profile</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

/* 🌊 Background */
body {
    background: linear-gradient(135deg, #dbeafe, #eff6ff);
    font-family: 'Poppins', sans-serif;
}

/* 📦 Card */
.card-box {
    border-radius: 15px;
    background: #ffffff;
    border: 1px solid #cfe2ff;
}

/* 🔵 Header */
.header h3 {
    color: #0d6efd;
    font-weight: 600;
}

/* 🧾 Inputs */
.form-control {
    border-radius: 10px;
    border: 1px solid #b6d4fe;
}

.form-control:focus {
    border-color: #0d6efd;
    box-shadow: 0 0 5px rgba(13,110,253,0.5);
}

/* 🎯 Buttons */
.btn-primary {
    background-color: #0d6efd;
    border: none;
}

.btn-primary:hover {
    background-color: #0b5ed7;
}

/* 🔙 Back */
.btn-secondary {
    background-color: #6c757d;
}

</style>

</head>
<body>

<%
Integer user_id = (Integer) session.getAttribute("loggedInuser_id");


if(user_id == null){
    response.sendRedirect("userlogin.jsp");
    return;
}

String GET_USER_BY_ID = "select * from users1 where user_id=?";

Connection con = null;
PreparedStatement ps = null;
ResultSet rs = null;

try {
    Class.forName("oracle.jdbc.driver.OracleDriver");
    con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","batch8","batch8");

    ps = con.prepareStatement(GET_USER_BY_ID);
    ps.setInt(1, user_id);

    rs = ps.executeQuery();

    if(rs.next()){
%>

<div class="container mt-5">
<div class="card-box p-4 shadow">

    <div class="header mb-4">
        <h3>
            <i class="fas fa-user-edit me-2"></i> Update User Profile
        </h3>
        <p class="opacity-75 mb-0">Edit your details</p>
    </div>

    <form action="update_Profile_controller.jsp" method="post">

        <!-- USER ID -->
        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="user_id"
                   value="<%=rs.getInt("user_id")%>" readonly>
            <label>User ID</label>
        </div>

        <!-- NAME -->
        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="user_name"
                   value="<%=rs.getString("user_name")%>">
            <label>Name</label>
        </div>

        <!-- EMAIL -->
        <div class="form-floating mb-3">
            <input type="email" class="form-control" name="email"
                   value="<%=rs.getString("email")%>">
            <label>Email</label>
        </div>

        <!-- PASSWORD -->
        <div class="form-floating mb-3">
            <input type="password" class="form-control" name="password"
                   value="<%=rs.getString("password")%>">
            <label>Password</label>
        </div>

        <!-- GENDER -->
        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="gender"
                   value="<%=rs.getString("gender")%>">
            <label>Gender</label>
        </div>

        <!-- PHONE -->
        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="phone_number"
                   value="<%=rs.getString("phone_number")%>">
            <label>Phone</label>
        </div>

        <!-- ADDRESS -->
        <div class="form-floating mb-3">
            <textarea class="form-control" name="address" style="height:100px;"><%=rs.getString("address")%></textarea>
            <label>Address</label>
        </div>

        <!-- CITY -->
        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="city"
                   value="<%=rs.getString("city")%>">
            <label>City</label>
        </div>

        <!-- PINCODE -->
        <div class="form-floating mb-3">
            <input type="number" class="form-control" name="pincode"
                   value="<%=rs.getInt("pincode")%>">
            <label>Pincode</label>
        </div>

        <!-- BUTTONS -->
        <button type="submit" class="btn btn-primary w-100 mb-2">
            <i class="fas fa-save me-1"></i> Update
        </button>

        <a href="userdashboard.jsp" class="btn btn-secondary w-100">
            <i class="fas fa-arrow-left me-1"></i> Back
        </a>

    </form>

</div>
</div>

<%
    } else {
%>
    <h3 class="text-center text-danger mt-5">User Not Found</h3>
<%
    }

} catch (Exception e) {
    e.printStackTrace();
} finally {
    if(rs!=null) rs.close();
    if(ps!=null) ps.close();
    if(con!=null) con.close();
}
%>

</body>
</html>
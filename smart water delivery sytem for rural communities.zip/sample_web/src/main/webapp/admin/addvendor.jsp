
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Add Vendor | Smart Water Delivery</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../CSS/addvendor.css"/>

</head>
<body>

<div class="title-bar">
💧 Smart Water Delivery System for Rural Communities
</div>

<nav class="navbar navbar-expand-lg navbar-custom">
  <div class="container d-flex justify-content-between">
    <ul class="navbar-nav flex-row">
      <li class="nav-item me-3"><a class="nav-link" href="#">Home</a></li>
      <li class="nav-item"><a class="nav-link active" href="#">Vendors</a></li>
    </ul>
    <a href="login.html" class="btn btn-logout">Logout</a>
  </div>
</nav>

<div class="admin-card">
<h3>➕ Add Vendor</h3>

<form action="add_vendor_controller.jsp" method="post" >



<!-- Name -->
<div class="mb-3">
<label class="form-label">Vendor Name</label>
<input type="text" name="vendor_name" class="form-control" required>
</div>

<!-- Email -->
<div class="mb-3">
<label class="form-label">Email</label>
<input type="email" name="vendor_email" class="form-control" required>
</div>

<!-- Password -->
<div class="mb-3">
<label class="form-label">Password</label>
<input type="password" name="password" class="form-control" required>
</div>

<!-- Phone -->
<div class="mb-3">
<label class="form-label">Phone Number</label>
<input type="text" name="phone_number" class="form-control" required>
</div>

<!-- Shop Name -->
<div class="mb-3">
<label class="form-label">Shop Name</label>
<input type="text" name="shop_name" class="form-control" required>
</div>

<!-- Shop Cover -->
<div class="mb-3">
<label class="form-label">Shop Cover Image</label>
<input type="file" name="shop_cover" class="form-control">
</div>

<!-- Rating -->
<div class="mb-3">
<label class="form-label">Rating</label>
<input type="number" name="rating" class="form-control" min="0" max="5" value="0">
</div>

<!-- Address -->
<div class="mb-3">
<label class="form-label">Shop Address</label>
<textarea name="shop_address" class="form-control" rows="3" required></textarea>
</div>

<!-- Location -->
<div class="mb-3">
<label class="form-label">Location </label>
<input type="text" name="location" class="form-control" required>
</div>

<!-- Pincode -->
<div class="mb-3">
<label class="form-label">Pincode</label>
<input type="text" name="pincode" class="form-control" required>
</div>

<div class="text-center mt-4">
<button type="button" onclick="history.back()" class="btn btn-back">⬅ Back</button>
<button type="submit" class="btn btn-submit">➕ Add Vendor</button>
</div>

</form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
